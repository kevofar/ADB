USE master;
GO

IF EXISTS (SELECT name FROM sys.databases WHERE name = 'FitnessCenterDB')
    DROP DATABASE FitnessCenterDB;
GO

CREATE DATABASE FitnessCenterDB;
GO

USE FitnessCenterDB;
GO

CREATE TABLE MEMBERSHIP (
    Membership_ID INT IDENTITY(1,1) PRIMARY KEY,
    M_Type VARCHAR(50) NOT NULL,
    Fee DECIMAL(10,2) NOT NULL CHECK (Fee > 0),
    Description VARCHAR(MAX),
    Duration_Days INT NOT NULL CHECK (Duration_Days > 0)
);
GO

CREATE TABLE BRANCH (
    Branch_ID INT IDENTITY(1,1) PRIMARY KEY,
    Branch_Name VARCHAR(100) NOT NULL UNIQUE,
    Location VARCHAR(200) NOT NULL,
    Capacity INT NOT NULL CHECK (Capacity > 0),
    Manager_ID INT NULL
);
GO

CREATE TABLE MANAGER (
    Manager_ID INT IDENTITY(1,1) PRIMARY KEY,
    First_Name VARCHAR(50) NOT NULL,
    Last_Name VARCHAR(50) NOT NULL,
    Phone_Number VARCHAR(20),
    Email VARCHAR(100) UNIQUE,
    Experience_Years INT DEFAULT 0,
    Branch_ID INT NULL,
    FOREIGN KEY (Branch_ID) REFERENCES BRANCH(Branch_ID)
);
GO

ALTER TABLE BRANCH ADD FOREIGN KEY (Manager_ID) REFERENCES MANAGER(Manager_ID);
GO

CREATE TABLE MEMBER (
    Member_ID INT IDENTITY(1,1) PRIMARY KEY,
    First_Name VARCHAR(50) NOT NULL,
    Last_Name VARCHAR(50) NOT NULL,
    Sex VARCHAR(10) CHECK (Sex IN ('Male','Female','Other')),
    Age INT CHECK (Age >= 16),
    Phone_Number VARCHAR(20) UNIQUE,
    Email VARCHAR(100) UNIQUE,
    Membership_ID INT NOT NULL,
    Join_Date DATE NOT NULL,
    End_Date DATE NOT NULL,
    Branch_ID INT NOT NULL,
    Status VARCHAR(20) DEFAULT 'Active' CHECK (Status IN ('Active','Inactive')),
    FOREIGN KEY (Membership_ID) REFERENCES MEMBERSHIP(Membership_ID),
    FOREIGN KEY (Branch_ID) REFERENCES BRANCH(Branch_ID)
);
GO

CREATE TABLE TRAINER (
    Trainer_ID INT IDENTITY(1,1) PRIMARY KEY,
    First_Name VARCHAR(50) NOT NULL,
    Last_Name VARCHAR(50) NOT NULL,
    Phone_Number VARCHAR(20) UNIQUE,
    Email VARCHAR(100) UNIQUE,
    Specialization VARCHAR(100),
    Experience_Years INT DEFAULT 0,
    Salary DECIMAL(10,2) CHECK (Salary > 0),
    Branch_ID INT NOT NULL,
    Status VARCHAR(10) DEFAULT 'Active' CHECK (Status IN ('Active','Inactive')),
    FOREIGN KEY (Branch_ID) REFERENCES BRANCH(Branch_ID)
);
GO

CREATE TABLE STAFF (
    Staff_ID INT IDENTITY(1,1) PRIMARY KEY,
    First_Name VARCHAR(50) NOT NULL,
    Last_Name VARCHAR(50) NOT NULL,
    Position VARCHAR(100) NOT NULL,
    Age INT CHECK (Age >= 18),
    Phone_Number VARCHAR(20) UNIQUE,
    Email VARCHAR(100) UNIQUE,
    Shift VARCHAR(15) CHECK (Shift IN ('Morning','Afternoon','Night')),
    Branch_ID INT,
    Salary DECIMAL(10,2) DEFAULT 0,
    FOREIGN KEY (Branch_ID) REFERENCES BRANCH(Branch_ID)
);
GO

CREATE TABLE ROOM (
    Room_ID INT IDENTITY(1,1) PRIMARY KEY,
    Room_Name VARCHAR(100) NOT NULL,
    Room_Type VARCHAR(100) NOT NULL,
    Floor INT CHECK (Floor >= 0),
    Capacity INT CHECK (Capacity > 0),
    Branch_ID INT NOT NULL,
    Status VARCHAR(15) DEFAULT 'Available' CHECK (Status IN ('Available','Maintenance','Occupied')),
    FOREIGN KEY (Branch_ID) REFERENCES BRANCH(Branch_ID)
);
GO

CREATE TABLE CLASS (
    Class_ID INT IDENTITY(1,1) PRIMARY KEY,
    Class_Name VARCHAR(100) NOT NULL,
    Schedule_Time TIME NOT NULL,
    Duration INT CHECK (Duration > 0),
    Trainer_ID INT NOT NULL,
    Room_ID INT NOT NULL,
    Max_Participants INT DEFAULT 20,
    Status VARCHAR(15) DEFAULT 'Scheduled' CHECK (Status IN ('Scheduled','Cancelled','Completed')),
    FOREIGN KEY (Trainer_ID) REFERENCES TRAINER(Trainer_ID),
    FOREIGN KEY (Room_ID) REFERENCES ROOM(Room_ID)
);
GO

CREATE TABLE CLASS_MATERIALS (
    Material_ID INT IDENTITY(1,1) PRIMARY KEY,
    Material_Name VARCHAR(100) NOT NULL,
    Type VARCHAR(100) NOT NULL,
    Size_or_Weight VARCHAR(50),
    Quantity INT CHECK (Quantity >= 0),
    Usage_Description VARCHAR(MAX),
    Class_ID INT NOT NULL,
    FOREIGN KEY (Class_ID) REFERENCES CLASS(Class_ID)
);
GO

CREATE TABLE PAYMENT (
    Member_ID INT NOT NULL,
    Membership_ID INT NOT NULL,
    Payment_Date DATE NOT NULL,
    Amount DECIMAL(10,2) CHECK (Amount > 0),
    Payment_Method VARCHAR(20) CHECK (Payment_Method IN ('Cash','Card','Mobile Payment','Bank Transfer')),
    Status VARCHAR(15) DEFAULT 'Completed' CHECK (Status IN ('Completed','Pending','Failed')),
    PRIMARY KEY (Member_ID, Membership_ID, Payment_Date),
    FOREIGN KEY (Member_ID) REFERENCES MEMBER(Member_ID),
    FOREIGN KEY (Membership_ID) REFERENCES MEMBERSHIP(Membership_ID)
);
GO

CREATE TABLE ATTENDANCE (
    Member_ID INT NOT NULL,
    Class_ID INT NOT NULL,
    Date DATE NOT NULL,
    Status VARCHAR(10) DEFAULT 'Present' CHECK (Status IN ('Present','Absent','Late')),
    Check_In_Time TIME,
    PRIMARY KEY (Member_ID, Class_ID, Date),
    FOREIGN KEY (Member_ID) REFERENCES MEMBER(Member_ID),
    FOREIGN KEY (Class_ID) REFERENCES CLASS(Class_ID)
);
GO

CREATE TABLE ENROLLMENT (
    Member_ID INT NOT NULL,
    Class_ID INT NOT NULL,
    Enrollment_Date DATE NOT NULL,
    Status VARCHAR(15) DEFAULT 'Enrolled' CHECK (Status IN ('Enrolled','Completed','Cancelled')),
    PRIMARY KEY (Member_ID, Class_ID),
    FOREIGN KEY (Member_ID) REFERENCES MEMBER(Member_ID),
    FOREIGN KEY (Class_ID) REFERENCES CLASS(Class_ID)
);
GO

-- Verify tables (optional)
SELECT 'Tables created' AS Status;