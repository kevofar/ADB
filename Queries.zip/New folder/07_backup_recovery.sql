-- ============================================
-- BACKUP AND RECOVERY STRATEGIES
-- ============================================
USE master;
GO

-- Set recovery model to FULL
ALTER DATABASE FitnessCenterDB SET RECOVERY FULL;
GO

-- Full backup (adjust disk path as needed)
BACKUP DATABASE FitnessCenterDB
TO DISK = 'C:\DB_Backups\FitnessCenterDB_Full.bak'
WITH FORMAT, INIT, NAME = 'Full Backup of FitnessCenterDB';
GO

-- Differential backup
BACKUP DATABASE FitnessCenterDB
TO DISK = 'C:\DB_Backups\FitnessCenterDB_Diff.bak'
WITH DIFFERENTIAL, NAME = 'Differential Backup';
GO

-- Transaction log backup
BACKUP LOG FitnessCenterDB
TO DISK = 'C:\DB_Backups\FitnessCenterDB_Log.trn'
WITH NAME = 'Transaction Log Backup';
GO

-- Example restore sequence (commented out)
/*
RESTORE DATABASE FitnessCenterDB
FROM DISK = 'C:\DB_Backups\FitnessCenterDB_Full.bak'
WITH NORECOVERY, REPLACE;

RESTORE DATABASE FitnessCenterDB
FROM DISK = 'C:\DB_Backups\FitnessCenterDB_Diff.bak'
WITH NORECOVERY;

RESTORE LOG FitnessCenterDB
FROM DISK = 'C:\DB_Backups\FitnessCenterDB_Log.trn'
WITH RECOVERY;
*/
GO

PRINT 'Backup scripts executed. Ensure folder C:\DB_Backups exists.';
GO