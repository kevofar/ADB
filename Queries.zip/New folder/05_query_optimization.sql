-- ============================================
-- QUERY OPTIMIZATION
-- ============================================
USE FitnessCenterDB;
GO

-- Slow query (before indexes)
SELECT 
    b.Branch_Name,
    YEAR(p.Payment_Date) AS PaymentYear,
    MONTH(p.Payment_Date) AS PaymentMonth,
    SUM(p.Amount) AS TotalRevenue,
    COUNT(DISTINCT p.Member_ID) AS UniqueMembers
FROM PAYMENT p
JOIN MEMBER m ON p.Member_ID = m.Member_ID
JOIN BRANCH b ON m.Branch_ID = b.Branch_ID
GROUP BY b.Branch_Name, YEAR(p.Payment_Date), MONTH(p.Payment_Date)
ORDER BY b.Branch_Name, PaymentYear, PaymentMonth;
GO

-- Create indexes
CREATE INDEX IX_PAYMENT_Date ON PAYMENT(Payment_Date);
CREATE INDEX IX_MEMBER_BranchID ON MEMBER(Branch_ID);
CREATE INDEX IX_PAYMENT_MemberID_Date ON PAYMENT(Member_ID, Payment_Date) INCLUDE (Amount);
CREATE INDEX IX_ENROLLMENT_ClassID ON ENROLLMENT(Class_ID);
CREATE INDEX IX_ATTENDANCE_MemberID_Date ON ATTENDANCE(Member_ID, Date);
GO

-- Query restructuring example
-- Inefficient:
SELECT Class_Name, 
    (SELECT COUNT(*) FROM ENROLLMENT e WHERE e.Class_ID = c.Class_ID) AS EnrollmentCount
FROM CLASS c;
GO

-- Efficient (use JOIN instead of subquery):
SELECT c.Class_Name, COUNT(e.Member_ID) AS EnrollmentCount
FROM CLASS c
LEFT JOIN ENROLLMENT e ON c.Class_ID = e.Class_ID
GROUP BY c.Class_ID, c.Class_Name;
GO

-- Enable statistics for performance comparison
SET STATISTICS IO ON;
SET STATISTICS TIME ON;
-- Run the slow query again to see improvement
GO