-- ============================================
-- CONCURRENCY CONTROL SIMULATION
-- ============================================
USE FitnessCenterDB;
GO

-- Add a test class with only 1 spot
INSERT INTO CLASS (Class_Name, Schedule_Time, Duration, Trainer_ID, Room_ID, Max_Participants)
VALUES ('Test Concurrency Class', '09:00:00', 60, 1, 1, 1);
GO

-- Instructions for two-session test:
-- Session 1 (run first):
/*
BEGIN TRANSACTION;
    SELECT * FROM ENROLLMENT WITH (UPDLOCK, HOLDLOCK) WHERE Class_ID = 6;
    WAITFOR DELAY '00:00:10';
    INSERT INTO ENROLLMENT (Member_ID, Class_ID, Enrollment_Date, Status)
    VALUES (100, 6, GETDATE(), 'ENROLLED');
COMMIT;
*/

-- Session 2 (run during the 10-second delay):
/*
BEGIN TRANSACTION;
    SELECT * FROM ENROLLMENT WITH (UPDLOCK, HOLDLOCK) WHERE Class_ID = 6;
    IF (SELECT COUNT(*) FROM ENROLLMENT WHERE Class_ID = 6) >= 1
    BEGIN
        ROLLBACK;
        PRINT 'Class full, enrollment failed.';
    END
    ELSE
    BEGIN
        INSERT INTO ENROLLMENT VALUES (101, 6, GETDATE(), 'ENROLLED');
        COMMIT;
    END
*/
GO

SET TRANSACTION ISOLATION LEVEL SERIALIZABLE;
GO

PRINT 'Concurrency scripts ready. Use two SSMS sessions to test.';
GO