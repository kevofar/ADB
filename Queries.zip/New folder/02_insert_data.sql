USE FitnessCenterDB;
GO

INSERT INTO MEMBERSHIP (M_Type, Fee, Description, Duration_Days) VALUES
('Monthly', 50.00, 'Basic monthly membership', 30),
('3-Month', 135.00, '3-month package', 90),
('Yearly', 500.00, 'Annual membership', 365),
('Premium', 80.00, 'Premium monthly', 30);
GO

INSERT INTO BRANCH (Branch_Name, Location, Capacity) VALUES
('Downtown Fitness', '123 Main Street', 200),
('Uptown Health Club', '456 Oak Avenue', 150),
('Westside Gym', '789 Pine Road', 180);
GO

INSERT INTO MANAGER (First_Name, Last_Name, Phone_Number, Email, Experience_Years, Branch_ID) VALUES
('John', 'Smith', '555-0101', 'john.smith@fitness.com', 5, 1),
('Sarah', 'Johnson', '555-0102', 'sarah.johnson@fitness.com', 3, 2),
('Michael', 'Brown', '555-0103', 'michael.brown@fitness.com', 7, 3);
GO

UPDATE BRANCH SET Manager_ID = 1 WHERE Branch_ID = 1;
UPDATE BRANCH SET Manager_ID = 2 WHERE Branch_ID = 2;
UPDATE BRANCH SET Manager_ID = 3 WHERE Branch_ID = 3;
GO

INSERT INTO MEMBER (First_Name, Last_Name, Sex, Age, Phone_Number, Email, Membership_ID, Join_Date, End_Date, Branch_ID) VALUES
('Alice', 'Williams', 'Female', 28, '555-0201', 'alice.w@email.com', 1, '2024-01-15', '2024-02-15', 1),
('Bob', 'Miller', 'Male', 35, '555-0202', 'bob.m@email.com', 2, '2024-01-10', '2024-04-10', 1),
('Carol', 'Davis', 'Female', 42, '555-0203', 'carol.d@email.com', 3, '2024-01-01', '2024-12-31', 2),
('David', 'Wilson', 'Male', 25, '555-0204', 'david.w@email.com', 4, '2024-01-20', '2024-02-20', 3);
GO

INSERT INTO TRAINER (First_Name, Last_Name, Phone_Number, Email, Specialization, Experience_Years, Salary, Branch_ID) VALUES
('Emma', 'Taylor', '555-0301', 'emma.t@fitness.com', 'Yoga, Pilates', 4, 3500.00, 1),
('James', 'Anderson', '555-0302', 'james.a@fitness.com', 'Weight Training', 6, 4000.00, 1),
('Lisa', 'Thomas', '555-0303', 'lisa.t@fitness.com', 'Zumba', 3, 3200.00, 2),
('Robert', 'Garcia', '555-0304', 'robert.g@fitness.com', 'CrossFit', 5, 3800.00, 3);
GO

INSERT INTO ROOM (Room_Name, Room_Type, Floor, Capacity, Branch_ID) VALUES
('Yoga Studio', 'Yoga Room', 1, 25, 1),
('Weight Room A', 'Weight Training', 1, 30, 1),
('Cardio Zone', 'Cardio Room', 2, 40, 1),
('Dance Studio', 'Dance Room', 1, 20, 2),
('CrossFit Box', 'Functional Training', 1, 15, 3);
GO

INSERT INTO CLASS (Class_Name, Schedule_Time, Duration, Trainer_ID, Room_ID, Max_Participants) VALUES
('Morning Yoga', '08:00:00', 60, 1, 1, 20),
('Strength Training', '10:00:00', 45, 2, 2, 15),
('Zumba Dance', '18:00:00', 60, 3, 4, 25),
('Evening Yoga', '19:00:00', 60, 1, 1, 20),
('CrossFit WOD', '17:00:00', 50, 4, 5, 12);
GO

INSERT INTO CLASS_MATERIALS (Material_Name, Type, Size_or_Weight, Quantity, Usage_Description, Class_ID) VALUES
('Yoga Mat', 'Mat', 'Standard', 25, 'For yoga', 1),
('Dumbbells', 'Weights', '5-20 lbs', 15, 'Strength training', 2),
('Resistance Bands', 'Bands', 'Various', 20, 'Flexibility', 2),
('Zumba Mat', 'Mat', 'Standard', 25, 'For dance', 3);
GO

INSERT INTO PAYMENT (Member_ID, Membership_ID, Payment_Date, Amount, Payment_Method) VALUES
(1, 1, '2024-01-15', 50.00, 'Card'),
(2, 2, '2024-01-10', 135.00, 'Cash'),
(3, 3, '2024-01-01', 500.00, 'Bank Transfer'),
(4, 4, '2024-01-20', 80.00, 'Mobile Payment');
GO

INSERT INTO ENROLLMENT (Member_ID, Class_ID, Enrollment_Date) VALUES
(1, 1, '2024-01-15'),
(1, 2, '2024-01-16'),
(2, 2, '2024-01-10'),
(3, 3, '2024-01-05'),
(4, 5, '2024-01-20');
GO

INSERT INTO ATTENDANCE (Member_ID, Class_ID, Date, Status, Check_In_Time) VALUES
(1, 1, '2024-01-16', 'Present', '08:00:00'),
(1, 2, '2024-01-17', 'Present', '10:00:00'),
(2, 2, '2024-01-17', 'Present', '10:05:00'),
(3, 3, '2024-01-18', 'Present', '18:00:00'),
(4, 5, '2024-01-21', 'Present', '17:00:00');
GO

SELECT 'Data inserted' AS Status;