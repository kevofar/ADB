-- ============================================
-- TRANSACTION MANAGEMENT
-- Enrollment and Payment stored procedures
-- ============================================
USE FitnessCenterDB;
GO

SET TRANSACTION ISOLATION LEVEL READ COMMITTED;
GO

CREATE OR ALTER PROCEDURE EnrollMember
    @MemberID INT,
    @ClassID INT,
    @EnrollmentDate DATE
AS
BEGIN
    SET NOCOUNT ON;
    BEGIN TRY
        BEGIN TRANSACTION;

        DECLARE @MaxParticipants INT, @CurrentEnrollment INT;

        SELECT @MaxParticipants = Max_Participants
        FROM CLASS
        WHERE Class_ID = @ClassID;

        SELECT @CurrentEnrollment = COUNT(*)
        FROM ENROLLMENT
        WHERE Class_ID = @ClassID AND Status = 'ENROLLED';

        IF @CurrentEnrollment >= @MaxParticipants
        BEGIN
            ROLLBACK;
            PRINT 'Enrollment failed: Class is full.';
            RETURN;
        END

        IF EXISTS (SELECT 1 FROM ENROLLMENT WHERE Member_ID = @MemberID AND Class_ID = @ClassID)
        BEGIN
            ROLLBACK;
            PRINT 'Enrollment failed: Member already enrolled in this class.';
            RETURN;
        END

        INSERT INTO ENROLLMENT (Member_ID, Class_ID, Enrollment_Date, Status)
        VALUES (@MemberID, @ClassID, @EnrollmentDate, 'ENROLLED');

        COMMIT;
        PRINT 'Enrollment successful.';
    END TRY
    BEGIN CATCH
        ROLLBACK;
        PRINT 'Error occurred: ' + ERROR_MESSAGE();
    END CATCH
END;
GO

CREATE OR ALTER PROCEDURE ProcessPayment
    @MemberID INT,
    @MembershipID INT,
    @Amount DECIMAL(10,2),
    @PaymentMethod VARCHAR(30),
    @PaymentDate DATE
AS
BEGIN
    SET NOCOUNT ON;
    BEGIN TRY
        BEGIN TRANSACTION;

        DECLARE @ExpectedFee DECIMAL(10,2);
        SELECT @ExpectedFee = Fee FROM MEMBERSHIP WHERE Membership_ID = @MembershipID;

        IF @ExpectedFee IS NULL
        BEGIN
            ROLLBACK;
            PRINT 'Invalid membership ID.';
            RETURN;
        END

        IF @Amount < @ExpectedFee
        BEGIN
            ROLLBACK;
            PRINT 'Payment amount less than required fee.';
            RETURN;
        END

        INSERT INTO PAYMENT (Member_ID, Membership_ID, Payment_Date, Amount, Payment_Method, Status)
        VALUES (@MemberID, @MembershipID, @PaymentDate, @Amount, @PaymentMethod, 'COMPLETED');

        DECLARE @DurationDays INT;
        SELECT @DurationDays = Duration_Days FROM MEMBERSHIP WHERE Membership_ID = @MembershipID;

        UPDATE MEMBER
        SET Membership_ID = @MembershipID,
            End_Date = DATEADD(DAY, @DurationDays, @PaymentDate)
        WHERE Member_ID = @MemberID;

        COMMIT;
        PRINT 'Payment processed and membership updated successfully.';
    END TRY
    BEGIN CATCH
        ROLLBACK;
        PRINT 'Payment failed: ' + ERROR_MESSAGE();
    END CATCH
END;
GO

-- Test procedures (optional)
-- EXEC EnrollMember 2, 1, '2025-05-12';
-- EXEC ProcessPayment 2, 1, 50.00, 'CARD', '2025-05-12';
GO