-- ============================================
-- SECURITY: ROLES, USERS, PRIVILEGES
-- ============================================
USE FitnessCenterDB;
GO

-- Create logins (server level)
CREATE LOGIN ManagerLogin WITH PASSWORD = 'Manager@123';
CREATE LOGIN TrainerLogin WITH PASSWORD = 'Trainer@123';
CREATE LOGIN MemberUser1 WITH PASSWORD = 'Member@123';
GO

-- Create database users
CREATE USER ManagerUser FOR LOGIN ManagerLogin;
CREATE USER TrainerUser FOR LOGIN TrainerLogin;
CREATE USER MemberUser FOR LOGIN MemberUser1;
GO

-- Create roles
CREATE ROLE ManagerRole;
CREATE ROLE TrainerRole;
CREATE ROLE MemberRole;
GO

-- Grant full control to ManagerRole
GRANT SELECT, INSERT, UPDATE, DELETE ON SCHEMA::dbo TO ManagerRole;
GO

-- Grant limited permissions to TrainerRole
GRANT SELECT ON CLASS TO TrainerRole;
GRANT SELECT, INSERT, UPDATE ON ATTENDANCE TO TrainerRole;
GRANT SELECT ON ENROLLMENT TO TrainerRole;
GRANT SELECT ON MEMBER TO TrainerRole;
DENY INSERT, UPDATE, DELETE ON PAYMENT TO TrainerRole;
DENY INSERT, UPDATE, DELETE ON MEMBERSHIP TO TrainerRole;
-- Column-level security: hide salary
DENY SELECT ON TRAINER (Salary) TO TrainerRole;
GO

-- Create view for MemberRole
CREATE VIEW Member_Own_Data AS
SELECT m.*, e.Class_ID, e.Enrollment_Date, a.Status AS AttendanceStatus
FROM MEMBER m
LEFT JOIN ENROLLMENT e ON m.Member_ID = e.Member_ID
LEFT JOIN ATTENDANCE a ON m.Member_ID = a.Member_ID;
GO

-- Grant MemberRole access
GRANT SELECT ON Member_Own_Data TO MemberRole;
GRANT SELECT ON MEMBERSHIP TO MemberRole;
GRANT SELECT ON PAYMENT TO MemberRole;
GO

-- Assign users to roles
ALTER ROLE ManagerRole ADD MEMBER ManagerUser;
ALTER ROLE TrainerRole ADD MEMBER TrainerUser;
ALTER ROLE MemberRole ADD MEMBER MemberUser;
GO

-- Revoke example
REVOKE DELETE ON ENROLLMENT FROM TrainerRole;
GO

PRINT 'Security setup complete.';
GO